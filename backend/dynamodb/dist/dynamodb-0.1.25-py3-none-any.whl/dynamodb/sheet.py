class Sheet(object):
    def __init__(self, db_client):
        self._db_client = db_client

    def set_data(self, data):
        self._data = data
    
    def get(self, user_id):
        return self._db_client.get('Sheet', user_id)
from containers import Configs, Models

# Incluir configuraciones de s3
Configs.config.override({
})

sheet_model = Models.sheet()


def fetch(event):
    id = None
    if 'multiValueQueryStringParameters' in event.keys() and event['multiValueQueryStringParameters'] != None:
        if 'id' in event['multiValueQueryStringParameters'].keys():
            id = event['multiValueQueryStringParameters']['id'][0]

    user_id = event['requestContext']['authorizer']['claims']['cognito:username']
    try:
        response = (sheet_model.get(user_id))
        if(id != None):
            for sheet in response:
                if(sheet['id'] == id):
                    return responseLambda(200, json.dumps(sheet))
            return responseLambda(404, json.dumps("Not Found: "+str(id)))
        return responseLambda(200, json.dumps(response))
    except:
        raise
        return responseLambda(200, json.dumps(event))    




# Función genérica para HTTP Response
def responseLambda(statusCode, data):
    return {
        'statusCode': statusCode,
        'body': data,
        "headers": {
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "*"
        },
        "isBase64Encoded": False
    }
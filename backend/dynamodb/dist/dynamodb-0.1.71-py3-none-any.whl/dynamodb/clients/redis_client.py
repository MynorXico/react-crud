import redis
import json

class RedisClient(object):
    def __init__(self, config):
        self._config = config
        self.connect(self._config)

    def connect(self, config):
        if(config):
            self.r = redis.Redis(config['host'])
        else:
            self.r = redis.Redis()

    def _get(self, key):
        value = self.r.get(key)
        if(value == None):
            return None
        try:
            return json.loads(self.r.get(key).decode('ascii'))
        except:
            try:
                return self.r.get(key).decode('ascii')
            except:
                return None
    def _set(self, key, value):
        if type(value) == str:
            return self.r.set(key, value)
        return self.r.set(key, json.dumps(value))
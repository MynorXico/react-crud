import boto3

class DatabseClient(object)
    def __init__(self, config):
        self._config = config
        self.connect(self._config)
    
    def connect(self, config):
        self.dynamodb = boto3.resource('dynamodb')
    
    def insert(self, table_name, data)
        table = self.dynamodb.Table(table_name)
        response = table.put_item(Item=data)
        return response
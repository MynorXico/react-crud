import json
import uuid

from .. import dynamo_functions

# Handler for create request
def create(event):
    try:
        json.loads(str(event['body']))
    except ValueError:
        return responseLambda(400, json.dumps("JSON no válido"))

    user_id = event['requestContext']['authorizer']['claims']['cognito:username']
    data = json.loads(event['body'])
    data['id'] = str(uuid.uuid1())
    data['date_added'] = str(datetime.now())
    data['date_modified'] = data['date_added']
    data['user_id'] = user_id

    try:
        response = (dynamo_functions.put_sheet(buildSheet(data)))
        return responseLambda(200, event['body'])
    except:
        return responseLambda(200, json.dumps(event))
    

def responseLambda(statusCode, data):
    return {
        'statusCode': statusCode,
        'body': data,
        "headers": {
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "*"
        },
        "isBase64Encoded": False
    }